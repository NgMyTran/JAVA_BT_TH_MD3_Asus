import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Khai báo 2 biến để nhập số dòng và số cột cho mảng 2 chiều từ bàn phím
        System.out.print("Nhập số dòng của ma trận: ");
        int rows = scanner.nextInt();
        System.out.print("Nhập số cột của ma trận: ");
        int columns = scanner.nextInt();

        // Bước 2: Khai báo 1 mảng 2 chiều với số dòng và cột ở trên và nhập từng giá trị cho mảng 2 chiều
        double[][] matrix = new double[rows][columns];

        System.out.println("Nhập các phần tử của ma trận:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print("Phần tử [" + i + "][" + j + "]: ");
                matrix[i][j] = scanner.nextDouble();
            }
        }

        // Bước 3: Hiển thị các giá trị của mảng 2 chiều vừa nhập
        System.out.println("Ma trận vừa nhập:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        // Bước 4: Khai báo 1 biến y nhập từ bàn phím là số cột cần tính tổng, kiểm tra điều kiện
        System.out.print("Nhập số thứ tự cột cần tính tổng (tính từ 0): ");
        int y = scanner.nextInt();

        if (y < 0 || y >= columns) {
            System.out.println("Số thứ tự cột không hợp lệ.");
        } else {
            // Bước 5: Khai báo 1 biến sum để tính tổng
            double sum = 0;

            for (int i = 0; i < rows; i++) {
                sum += matrix[i][y];
            }

            // In ra tổng của cột đã chọn
            System.out.println("Tổng của cột " + y + " là: " + sum);
        }

        scanner.close();
    }
}