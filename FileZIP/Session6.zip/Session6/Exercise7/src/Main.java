import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Khai báo 1 biến để nhập số dòng và số cột cho mảng 2 chiều từ bàn phím
        System.out.print("Nhập kích thước của ma trận vuông: ");
        int size = scanner.nextInt();

        // Bước 2: Khai báo 1 mảng 2 chiều là ma trận vuông và nhập từng giá trị cho ma trận
        int[][] matrix = new int[size][size];

        System.out.println("Nhập các phần tử của ma trận:");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print("Phần tử [" + i + "][" + j + "]: ");
                matrix[i][j] = scanner.nextInt();
            }
        }

        // Bước 3: Hiển thị các giá trị của ma trận vừa nhập
        System.out.println("Ma trận vừa nhập:");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        // Bước 4: Khai báo biến tính tổng cho đường chéo chính và đường chéo phụ
        int sumMainDiagonal = 0;
        int sumAntiDiagonal = 0;

        // Bước 5: Duyệt các phần tử của ma trận vuông để tính tổng
        for (int i = 0; i < size; i++) {
            sumMainDiagonal += matrix[i][i];  // Đường chéo chính
            sumAntiDiagonal += matrix[i][size - 1 - i];  // Đường chéo phụ
        }

        // In ra tổng của đường chéo chính và đường chéo phụ
        System.out.println("Tổng của các phần tử trên đường chéo chính: " + sumMainDiagonal);
        System.out.println("Tổng của các phần tử trên đường chéo phụ: " + sumAntiDiagonal);

        scanner.close();
    }
}
