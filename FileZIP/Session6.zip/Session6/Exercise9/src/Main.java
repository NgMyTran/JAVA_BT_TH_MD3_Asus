//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        int[] array = {3, 5, 7, 2, 8, 10, 6, 4, 9};

        // Bước 1: Tìm phần tử lớn nhất
        int max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
            }
        }

        // Bước 2: Tìm phần tử lớn thứ 2
        int max2 = Integer.MIN_VALUE;
        for (int i = 0; i < array.length; i++) {
            if (array[i] != max && array[i] > max2) {
                max2 = array[i];
            }
        }

        System.out.println("Phần tử lớn thứ 2 là: " + max2);
    }
}