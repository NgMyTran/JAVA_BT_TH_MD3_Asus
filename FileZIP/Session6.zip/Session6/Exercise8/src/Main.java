import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Khai báo một chuỗi và gán cho nó một giá trị
        String str = "This is a sample string for counting characters.";

        // Bước 2: Khai báo một biến ký tự và gán hoặc nhập từ bàn phím một giá trị
        System.out.print("Nhập vào một ký tự để đếm: ");
        char ch = scanner.next().charAt(0);

        // Bước 3: Khai báo biến count và gán giá trị 0, để lưu số ký tự đếm được trong chuỗi
        int count = 0;

        // Bước 4: Sử dụng vòng lặp duyệt từng ký tự trong chuỗi
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == ch) {
                count++;
            }
        }

        // Bước 5: In ra giá trị biến đếm
        System.out.println("Số lần xuất hiện của ký tự '" + ch + "' trong chuỗi là: " + count);

        scanner.close();
    }
}