import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Khai báo 2 biến kiểu int nhập từ bàn phím để dùng làm số dòng và cột của mảng 2 chiều
        System.out.print("Nhập số dòng của ma trận: ");
        int rows = scanner.nextInt();
        System.out.print("Nhập số cột của ma trận: ");
        int columns = scanner.nextInt();

        // Khai báo mảng 2 chiều với số dòng và số cột đã nhập
        double[][] matrix = new double[rows][columns];

        // Bước 2: Nhập giá trị cho từng phần tử trong mảng 2 chiều
        System.out.println("Nhập các phần tử của ma trận:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print("Phần tử [" + i + "][" + j + "]: ");
                matrix[i][j] = scanner.nextDouble();
            }
        }

        // Bước 3: Tìm phần tử lớn nhất trong ma trận
        double max = matrix[0][0];
        int maxRow = 0;
        int maxColumn = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrix[i][j] > max) {
                    max = matrix[i][j];
                    maxRow = i;
                    maxColumn = j;
                }
            }
        }

        // Bước 4: In ra giá trị lớn nhất và vị trí của nó trong ma trận
        System.out.println("Giá trị lớn nhất trong ma trận là: " + max);
        System.out.println("Vị trí của phần tử lớn nhất là: [" + maxRow + "][" + maxColumn + "]");

        scanner.close();
    }
}