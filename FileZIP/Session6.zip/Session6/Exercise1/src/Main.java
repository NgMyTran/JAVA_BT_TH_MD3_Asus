//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Bước 1: Khai báo các biến kiểu String
        String str = "   Hello Java World!   ";
        String str2 = "hello java world!";
        String str3 = "Java";

        // Bước 2: Sử dụng từng phương thức liệt kê ở trên

        // isEmpty()
        System.out.println("isEmpty: " + str.isEmpty());

        // trim()
        String trimmedStr = str.trim();
        System.out.println("trim: '" + trimmedStr + "'");

        // equals() và equalsIgnoreCase()
        System.out.println("equals: " + str.equals(str2));
        System.out.println("equalsIgnoreCase: " + str.equalsIgnoreCase(str2));

        // split()
        String[] words = trimmedStr.split(" ");
        System.out.print("split: ");
        for (String word : words) {
            System.out.print("'" + word + "' ");
        }
        System.out.println();

        // concat()
        String concatenatedStr = trimmedStr.concat(" Let's code!");
        System.out.println("concat: " + concatenatedStr);

        // contains()
        System.out.println("contains: " + trimmedStr.contains(str3));

        // toUpperCase()
        String upperStr = trimmedStr.toUpperCase();
        System.out.println("toUpperCase: " + upperStr);

        // toLowerCase()
        String lowerStr = trimmedStr.toLowerCase();
        System.out.println("toLowerCase: " + lowerStr);

        // replace()
        String replacedStr = trimmedStr.replace("Java", "Python");
        System.out.println("replace: " + replacedStr);

        // length()
        System.out.println("length: " + trimmedStr.length());
    }
}