import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Tạo 2 mảng số với kích thước cho trước
        final int SIZE1 = 5; // Kích thước của mảng 1
        final int SIZE2 = 5; // Kích thước của mảng 2

        int[] array1 = new int[SIZE1];
        int[] array2 = new int[SIZE2];

        // Bước 2: Sử dụng vòng lặp nhập giá trị cho các phần tử trong mảng 1
        System.out.println("Nhập các phần tử cho mảng 1:");
        for (int i = 0; i < SIZE1; i++) {
            System.out.print("Phần tử thứ " + (i + 1) + ": ");
            array1[i] = scanner.nextInt();
        }

        // Sử dụng vòng lặp nhập giá trị cho các phần tử trong mảng 2
        System.out.println("Nhập các phần tử cho mảng 2:");
        for (int i = 0; i < SIZE2; i++) {
            System.out.print("Phần tử thứ " + (i + 1) + ": ");
            array2[i] = scanner.nextInt();
        }

        // Bước 3: Tạo mảng thứ 3 có kích thước bằng kích thước mảng 1 + kích thước mảng 2
        int[] mergedArray = new int[SIZE1 + SIZE2];

        // Bước 4: Sử dụng vòng lặp để duyệt các phần tử trong mảng 1
        for (int i = 0; i < SIZE1; i++) {
            mergedArray[i] = array1[i];
        }

        // Bước 5: Sử dụng vòng lặp để duyệt các phần tử trong mảng 2
        for (int i = 0; i < SIZE2; i++) {
            mergedArray[SIZE1 + i] = array2[i];
        }

        // In ra mảng thứ 3
        System.out.println("Mảng gộp từ mảng 1 và mảng 2:");
        for (int i = 0; i < mergedArray.length; i++) {
            System.out.print(mergedArray[i] + " ");
        }
        System.out.println();

        scanner.close();
    }
}