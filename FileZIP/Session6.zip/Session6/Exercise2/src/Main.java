import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Bước 1: Khai báo và khởi tạo mảng số nguyên gồm N phần tử cho trước
        final int N = 10;
        int[] array = new int[N];

        // In ra mảng ban đầu
        System.out.println("Dòng value: ");
        for (int i = 0; i < N; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        System.out.println("Dòng index: ");
        for (int i = 0; i < N; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        // Bước 2: Nhập X là số cần chèn
        System.out.print("Nhập giá trị cần chèn X: ");
        int X = scanner.nextInt();

        // Bước 3: Nhập vào vị trí index cần chèn X vào trong mảng
        System.out.print("Nhập vị trí index cần chèn X: ");
        int index = scanner.nextInt();

        // Bước 4: Kiểm tra điều kiện index có hợp lệ hay không
        if (index < 0 || index > array.length - 1) {
            System.out.println("Không chèn được phần tử vào mảng.");
        } else {
            // Bước 5: Thực hiện chèn phần tử X ở vị trí index vào mảng
            for (int i = array.length - 1; i > index; i--) {
                array[i] = array[i - 1];
            }
            array[index] = X;

            // Bước 6: In ra mảng
            System.out.println("Dòng new value: ");
            for (int i = 0; i < N; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        }

        scanner.close();
    }
}